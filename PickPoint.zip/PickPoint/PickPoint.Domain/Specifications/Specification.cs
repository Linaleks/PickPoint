﻿using System.Linq;

namespace PickPoint.Domain.Specifications
{
    /// <summary>
    /// Условие фильтра
    /// </summary>
    /// <typeparam name="T">Сущность</typeparam>
    public abstract class Specification<T> where T : class
    {
        /// <summary>
        /// Применить условие к запросу
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public abstract IQueryable<T> Apply(IQueryable<T> query);

        /// <summary>
        /// Применить оба условия к запросу
        /// </summary>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        public static Specification<T> operator &(Specification<T> first, Specification<T> second)
        {
            return new AndSpecification<T>(first, second);
        }

        /// <summary>
        /// Применить условие ИЛИ к запросу
        /// </summary>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        public static Specification<T> operator |(Specification<T> first, Specification<T> second)
        {
            return new OrSpecification<T>(first, second);
        }
    }
}
