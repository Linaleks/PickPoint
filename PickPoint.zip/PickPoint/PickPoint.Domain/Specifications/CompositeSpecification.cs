﻿namespace PickPoint.Domain.Specifications
{
    public abstract class CompositeSpecification<TEntity> : Specification<TEntity> where TEntity : class
    {
        protected readonly Specification<TEntity>[] specifications;

        public CompositeSpecification(params Specification<TEntity>[] specifications)
        {
            this.specifications = specifications;
        }
    }
}
