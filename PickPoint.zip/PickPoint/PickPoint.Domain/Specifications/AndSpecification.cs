﻿using System.Linq;

namespace PickPoint.Domain.Specifications
{

    public sealed class AndSpecification<TEntity> : CompositeSpecification<TEntity> where TEntity : class
    {
        public AndSpecification(params Specification<TEntity>[] specifications) : base(specifications)
        {
        }

        public override IQueryable<TEntity> Apply(IQueryable<TEntity> query)
        {
            foreach (var specification in specifications.Where(e => e != null))
            {
                query = specification.Apply(query);
            }

            return query;
        }
    }
}
