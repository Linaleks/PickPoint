﻿using System.Collections.Generic;
using System.Linq;

namespace PickPoint.Domain.Specifications
{
    public sealed class OrSpecification<TEntity> : CompositeSpecification<TEntity> where TEntity : class
    {
        public OrSpecification(params Specification<TEntity>[] specifications) : base(specifications)
        {
        }

        public override IQueryable<TEntity> Apply(IQueryable<TEntity> query)
        {
            List<IQueryable<TEntity>> result = new List<IQueryable<TEntity>>();
            foreach (var specification in specifications)
            {
                result.Add(specification.Apply(query));
            }

            IQueryable<TEntity> qq = result.First();

            foreach (var q in result.Skip(1))
            {
                qq = qq.Union(q);
            }

            return qq;
        }
    }
}
