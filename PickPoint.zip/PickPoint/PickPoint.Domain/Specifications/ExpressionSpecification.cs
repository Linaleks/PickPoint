﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace PickPoint.Domain.Specifications
{
    public class ExpressionSpecification<T> : Specification<T> where T : class
    {
        private readonly Expression<Func<T, bool>> expression;

        public ExpressionSpecification(Expression<Func<T, bool>> expression)
        {
            this.expression = expression ?? throw new ArgumentNullException(nameof(expression));
        }

        public override IQueryable<T> Apply(IQueryable<T> query) => query.Where(expression);
    }
}
