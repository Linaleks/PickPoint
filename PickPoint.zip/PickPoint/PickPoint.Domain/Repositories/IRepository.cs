﻿using PickPoint.Domain.Specifications;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace PickPoint.Domain.Repositories
{
    public interface IRepository<T> where T : class
    {
        T Get(int id);
        T FirstOrDefault(Specification<T> specification, IEnumerable<string> navigationPropertyPathes = null);
        T FirstOrDefault<TKey>(Specification<T> specification, Expression<Func<T, TKey>> orderBy, IEnumerable<string> navigationPropertyPathes = null);
        IEnumerable<T> GetAll(Specification<T> specification, IEnumerable<string> navigationPropertyPathes = null);
        IEnumerable<T> GetAll<TKey>(Specification<T> specification, Expression<Func<T, TKey>> orderBy, IEnumerable<string> navigationPropertyPathes = null);
        IEnumerable<T> GetAll<TKey>(Specification<T> specification, Expression<Func<T, TKey>> orderBy, int count, IEnumerable<string> navigationPropertyPathes = null);
        IEnumerable<T> GetAll<TKey>(Specification<T> specification, Expression<Func<T, TKey>> orderBy, int skip, int count, IEnumerable<string> navigationPropertyPathes = null);
        int Count(Specification<T> specification);
        void Add(T entity);
        void AddRange(IEnumerable<T> entities);
        void Remove(T entity);
        void RemoveRange(IEnumerable<T> entities);
        void Save();
    }
}
