﻿using PickPoint.Domain.Entities;

namespace PickPoint.Domain.Repositories
{
    public interface IPostamatRepository : IRepository<Postamat>
    {
    }
}
