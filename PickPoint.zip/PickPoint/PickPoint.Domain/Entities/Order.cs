﻿using PickPoint.Domain.Enums;
using System.Collections.Generic;

namespace PickPoint.Domain.Entities
{
    public class Order
    {
        public int Id { get; set; }
        public OrderStatus Status { get; set; }
        public decimal TotalCost { get; set; }
        public int PostamatId { get; set; }
        public string RecipientPhoneNumber { get; set; }
        public string RecipientName { get; set; }
        public virtual Postamat Postamat { get; set; }
        public virtual ICollection<OrderDetail> OrderDetails { get; set; }
    }
}
