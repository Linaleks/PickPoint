﻿namespace PickPoint.Domain.Entities
{
    public class OrderDetail
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public string ProductName { get; set; }
        public virtual Order OrderHeader { get; set; }
    }
}
