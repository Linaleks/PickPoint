﻿namespace PickPoint.Domain.Enums
{
    public enum OrderStatus : int
    {
        Registered = 1,
        AcceptedInStock = 2,
        IssuedToTheCourier = 3,
        DeliveredToPostamat = 4,
        DeliveredToRecipient = 5,
        Canceled = 6
    }
}
