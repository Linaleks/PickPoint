﻿namespace PickPoint.Utility
{
    public static class WebConsts
    {
        public const string PostamatNumberFormat = "\\d\\d\\d\\d\\-\\d\\d\\d";
        public const string PhoneNumberFormat = "\\+7\\d\\d\\d\\-\\d\\d\\d\\-\\d\\d\\-\\d\\d";

        public const string OrderNotFound = "Заказ не найден";
        public const string OrderAlreadyCancelled = "Заказ уже отменён";
        public const string QueryError = "Ошибка запроса";
        public const string PostamatNotFound = "Постамат не найден";
        public const string Restricted = "Запрещено";

        public const int MaxOrderDetailCount = 10;
    }
}
