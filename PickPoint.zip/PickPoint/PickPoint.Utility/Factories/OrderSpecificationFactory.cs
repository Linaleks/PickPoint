﻿using PickPoint.Domain.Entities;
using PickPoint.Domain.Enums;
using PickPoint.Domain.Specifications;

namespace PickPoint.Utility.Factories
{
    public static class OrderSpecificationFactory
    {
        public static Specification<Order> GetById(int id) =>
            new ExpressionSpecification<Order>(e => e.Id == id);

        public static Specification<Order> GetByStatus(OrderStatus status, bool exclude = false) =>
            exclude ? new ExpressionSpecification<Order>(e => e.Status != status) : new ExpressionSpecification<Order>(e => e.Status == status);
    }
}
