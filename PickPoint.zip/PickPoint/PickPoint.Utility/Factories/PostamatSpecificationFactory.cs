﻿using PickPoint.Domain.Entities;
using PickPoint.Domain.Specifications;

namespace PickPoint.Utility.Factories
{
    public static class PostamatSpecificationFactory
    {
        public static Specification<Postamat> GetByStatus(bool status) => new ExpressionSpecification<Postamat>(e => e.Status == status);
        public static Specification<Postamat> GetByNumber(string number) => new ExpressionSpecification<Postamat>(e => e.Number == number);
    }
}
