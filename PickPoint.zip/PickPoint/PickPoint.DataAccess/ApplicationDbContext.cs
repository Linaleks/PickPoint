﻿using Microsoft.EntityFrameworkCore;
using PickPoint.Domain.Entities;
using PickPoint.DataAccess.Configurations;

namespace PickPoint.DataAccess
{
    public class ApplicationDbContext : DbContext
    {
        #region DbSets

        public DbSet<Postamat> Postamats { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }

        #endregion

        #region Constructors

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        #endregion

        #region Infrastructure

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            EntityConfiguration.CreateModel(modelBuilder);
        }

        #endregion
    }
}
