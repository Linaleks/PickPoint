﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PickPoint.Domain.Entities;

namespace PickPoint.DataAccess.Configurations
{
    public class OrderConfiguration : IEntityTypeConfiguration<Order>
    {
        public void Configure(EntityTypeBuilder<Order> builder)
        {
            builder
                .HasKey(e => e.Id);

            builder
                .Property(e => e.Status)
                .HasColumnType("int");

            builder
                .Property(e => e.RecipientPhoneNumber)
                .HasMaxLength(64)
                .IsRequired();

            builder
                .Property(e => e.RecipientName)
                .HasMaxLength(255)
                .IsRequired();

            builder
                .Property(e => e.TotalCost)
                .HasDefaultValue(0);

            builder
                .HasOne(e => e.Postamat)
                .WithMany(e => e.Orders)
                .HasForeignKey(e => e.PostamatId)
                .OnDelete(DeleteBehavior.NoAction);

            builder
                .HasMany(e => e.OrderDetails)
                .WithOne(e => e.OrderHeader)
                .HasForeignKey(e => e.OrderId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
