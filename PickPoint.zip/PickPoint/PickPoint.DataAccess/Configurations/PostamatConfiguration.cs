﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PickPoint.Domain.Entities;
using System;

namespace PickPoint.DataAccess.Configurations
{
    class PostamatConfiguration : IEntityTypeConfiguration<Postamat>
    {
        public void Configure(EntityTypeBuilder<Postamat> builder)
        {
            builder
                .HasKey(e => e.Id);

            builder
                .Property(e => e.Number)
                .HasMaxLength(8)
                .IsRequired();

            builder
                .Property(e => e.Address)
                .HasMaxLength(255)
                .IsRequired();

            builder
                .HasMany(e => e.Orders)
                .WithOne(e => e.Postamat)
                .HasForeignKey(e => e.PostamatId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
