﻿using Microsoft.EntityFrameworkCore;

namespace PickPoint.DataAccess.Configurations
{
    public static class EntityConfiguration
    {
        public static void CreateModel(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new PostamatConfiguration());
            modelBuilder.ApplyConfiguration(new OrderConfiguration());
            modelBuilder.ApplyConfiguration(new OrderDetailConfiguration());
        }
    }
}
