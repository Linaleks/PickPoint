﻿using PickPoint.Domain.Entities;
using PickPoint.Domain.Repositories;

namespace PickPoint.DataAccess.Repositories
{
    public class PostamatRepository : Repository<Postamat>, IPostamatRepository
    {
        public PostamatRepository(ApplicationDbContext db) : base(db)
        {
        }
    }
}
