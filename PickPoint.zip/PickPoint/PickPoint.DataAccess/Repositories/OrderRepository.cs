﻿using PickPoint.Domain.Entities;
using PickPoint.Domain.Repositories;

namespace PickPoint.DataAccess.Repositories
{
    public class OrderRepository : Repository<Order>, IOrderRepository
    {
        public OrderRepository(ApplicationDbContext db) : base(db)
        {
        }
    }
}
