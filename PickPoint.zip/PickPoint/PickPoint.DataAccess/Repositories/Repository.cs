﻿using Microsoft.EntityFrameworkCore;
using PickPoint.Domain.Repositories;
using PickPoint.Domain.Specifications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace PickPoint.DataAccess.Repositories
{
    public class Repository<T> : IRepository<T> where T : class
    {
        #region Fields

        private readonly ApplicationDbContext db;
        private readonly DbSet<T> dbSet;

        #endregion

        #region Properties

        protected DbSet<T> DbSet => dbSet;
        protected ApplicationDbContext DbContext => db;

        #endregion

        #region Constructors

        public Repository(ApplicationDbContext db)
        {
            this.db = db;
            dbSet = db.Set<T>();
        }

        #endregion

        #region Infrastructure

        private IQueryable<T> IncludeNavigationProperties(IQueryable<T> query, IEnumerable<string> navigationPropertyPathes)
        {
            if (navigationPropertyPathes != null)
            {
                foreach (var path in navigationPropertyPathes)
                {
                    query = query.Include(path);
                }
            }

            return query;
        }

        #endregion

        #region IRepository<T>

        public void Add(T entity)
        {
            DbSet.Add(entity);
        }

        public void AddRange(IEnumerable<T> entities)
        {
            DbSet.AddRange(entities);
        }

        public int Count(Specification<T> specification)
        {
            return specification
             .Apply(DbSet)
             .Count();
        }

        public T FirstOrDefault(Specification<T> specification, IEnumerable<string> navigationPropertyPathes = null)
        {
            var query = specification.Apply(DbSet);
            query = IncludeNavigationProperties(query, navigationPropertyPathes);
            return query.FirstOrDefault();
        }

        public T FirstOrDefault<TKey>(Specification<T> specification, Expression<Func<T, TKey>> orderBy, IEnumerable<string> navigationPropertyPathes = null)
        {
            var query = specification.Apply(DbSet);
            query = IncludeNavigationProperties(query, navigationPropertyPathes);
            return query
                .OrderBy(orderBy)
                .FirstOrDefault();
        }

        public T Get(int id)
        {
            return DbSet.Find(id);
        }

        public IEnumerable<T> GetAll(Specification<T> specification, IEnumerable<string> navigationPropertyPathes = null)
        {
            var query = specification.Apply(DbSet);
            query = IncludeNavigationProperties(query, navigationPropertyPathes);
            return query.ToList();
        }

        public IEnumerable<T> GetAll<TKey>(Specification<T> specification, Expression<Func<T, TKey>> orderBy, IEnumerable<string> navigationPropertyPathes = null)
        {
            var query = specification.Apply(DbSet);
            query = IncludeNavigationProperties(query, navigationPropertyPathes);
            return query
                 .OrderBy(orderBy)
                 .ToList();
        }

        public IEnumerable<T> GetAll<TKey>(Specification<T> specification, Expression<Func<T, TKey>> orderBy, int count, IEnumerable<string> navigationPropertyPathes = null)
        {
            var query = specification.Apply(DbSet);
            query = IncludeNavigationProperties(query, navigationPropertyPathes);
            return query
                 .OrderBy(orderBy)
                 .Take(count)
                 .ToList();
        }

        public IEnumerable<T> GetAll<TKey>(Specification<T> specification, Expression<Func<T, TKey>> orderBy, int skip, int count, IEnumerable<string> navigationPropertyPathes = null)
        {
            var query = specification.Apply(DbSet);
            query = IncludeNavigationProperties(query, navigationPropertyPathes);
            return query
                .OrderBy(orderBy)
                .Skip(skip)
                .Take(count)
                .ToList();
        }

        public void Remove(T entity)
        {
            DbSet.Remove(entity);
        }

        public void RemoveRange(IEnumerable<T> entities)
        {
            DbSet.RemoveRange(entities);
        }

        public void Save()
        {
            db.SaveChanges();
        }

        #endregion
    }
}
