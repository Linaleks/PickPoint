﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PickPoint.DataAccess.Migrations
{
    public partial class SeedOrdersAndOrderDetailsTables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("insert into dbo.Orders (Status, TotalCost, PostamatId, RecipientPhoneNumber, RecipientName) select 1, 100, Id, '+7900-000-00-00', 'Алексей' from dbo.Postamats (nolock) where Number = '1234-567';" +
                "declare @id int = scope_identity();" +
                "if @id is not null insert into dbo.OrderDetails(OrderId, ProductName) values(@id, 'Товар 1'), (@id, 'Товар 2');");
            migrationBuilder.Sql("insert into dbo.Orders (Status, TotalCost, PostamatId, RecipientPhoneNumber, RecipientName) select 1, 100, Id, '+7901-000-00-00', 'Иван' from dbo.Postamats (nolock) where Number = '1234-560';" +
                "declare @id int = scope_identity();" +
                "if @id is not null insert into dbo.OrderDetails (OrderId, ProductName) values (@id, 'Товар 3'), (@id, 'Товар 4'), (@id, 'Товар 5'), (@id, 'Товар 6'), (@id, 'Товар 7');");
            migrationBuilder.Sql("insert into dbo.Orders (Status, TotalCost, PostamatId, RecipientPhoneNumber, RecipientName) select 2, 100, Id, '+7907-000-00-00', 'Пётр' from dbo.Postamats (nolock) where Number = '1234-568';" +
                "declare @id int = scope_identity();" +
                "if @id is not null insert into dbo.OrderDetails (OrderId, ProductName) values (@id, 'Товар 1'), (@id, 'Товар 3'), (@id, 'Товар 9');");
            migrationBuilder.Sql("insert into dbo.Orders (Status, TotalCost, PostamatId, RecipientPhoneNumber, RecipientName) select 6, 100, Id, '+7903-000-00-00', 'Василий' from dbo.Postamats (nolock) where Number = '1234-567';" +
                "declare @id int = scope_identity();" +
                "if @id is not null insert into dbo.OrderDetails (OrderId, ProductName) values (@id, 'Товар 11'), (@id, 'Товар 3'), (@id, 'Товар 2');");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
