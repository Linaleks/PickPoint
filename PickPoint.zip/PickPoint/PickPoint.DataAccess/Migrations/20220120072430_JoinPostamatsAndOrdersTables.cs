﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PickPoint.DataAccess.Migrations
{
    public partial class JoinPostamatsAndOrdersTables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Orders_PostamatId",
                table: "Orders",
                column: "PostamatId");

            migrationBuilder.AddForeignKey(
                name: "FK_Orders_Postamats_PostamatId",
                table: "Orders",
                column: "PostamatId",
                principalTable: "Postamats",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Orders_Postamats_PostamatId",
                table: "Orders");

            migrationBuilder.DropIndex(
                name: "IX_Orders_PostamatId",
                table: "Orders");
        }
    }
}
