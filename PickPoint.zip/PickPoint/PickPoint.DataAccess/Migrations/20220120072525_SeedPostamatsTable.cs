﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PickPoint.DataAccess.Migrations
{
    public partial class SeedPostamatsTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql($"if not exists (select top(1) Id from dbo.Postamats (nolock) where Number = '1234-567') insert into dbo.Postamats (Number, Address, Status) values ('1234-567', 'Москва', 1);");
            migrationBuilder.Sql($"if not exists (select top(1) Id from dbo.Postamats (nolock) where Number = '1234-568') insert into dbo.Postamats (Number, Address, Status) values ('1234-568', 'Воронеж', 1);");
            migrationBuilder.Sql($"if not exists (select top(1) Id from dbo.Postamats (nolock) where Number = '1234-569') insert into dbo.Postamats (Number, Address, Status) values ('1234-569', 'Санкт-Петербург', 1);");
            migrationBuilder.Sql($"if not exists (select top(1) Id from dbo.Postamats (nolock) where Number = '1234-560') insert into dbo.Postamats (Number, Address, Status) values ('1234-560', 'Нижний Новгород', 1);");
            migrationBuilder.Sql($"if not exists (select top(1) Id from dbo.Postamats (nolock) where Number = '1234-111') insert into dbo.Postamats (Number, Address, Status) values ('1234-111', 'Москва', 0);");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
