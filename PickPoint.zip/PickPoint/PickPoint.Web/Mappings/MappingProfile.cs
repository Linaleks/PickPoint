﻿using AutoMapper;
using PickPoint.Domain.Entities;
using PickPoint.Domain.Enums;
using PickPoint.Web.Models;
using System.Linq;

namespace PickPoint.Web.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Postamat, PostamatModel>();
            CreateMap<PostamatModel, Postamat>();
            CreateMap<Order, OrderModel>()
                .ForMember(dest => dest.Status, a => a.MapFrom(src => (int)src.Status))
                .ForMember(dest => dest.Postamat, a => a.MapFrom(src => src.Postamat.Number))
                .ForMember(dest => dest.Products, a => a.MapFrom(src => src.OrderDetails.Select(e => e.ProductName).ToArray()));
            CreateMap<OrderModel, Order>()
                .ForMember(dest => dest.Status, a => a.MapFrom(src => (OrderStatus)src.Status))
                .ForMember(dest => dest.Postamat, a => a.MapFrom(src => new Postamat { Number = src.Postamat }))
                .ForMember(dest => dest.OrderDetails, a => a.MapFrom(src => src.Products.Select((e, index) => new OrderDetail { ProductName = e }).ToList()));
        }
    }
}
