﻿using PickPoint.Utility;
using System.ComponentModel.DataAnnotations;

namespace PickPoint.Web.Models
{
    public class PostamatModel
    {
        [Required]
        [RegularExpression(WebConsts.PostamatNumberFormat, ErrorMessage = WebConsts.QueryError)]
        public string Number { get; set; }
        [Required]
        [MaxLength(255, ErrorMessage = WebConsts.QueryError)]
        public string Address { get; set; }
        public bool Status { get; set; }
    }
}
