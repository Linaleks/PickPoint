﻿using PickPoint.Domain.Enums;
using PickPoint.Utility;
using System;
using System.ComponentModel.DataAnnotations;

namespace PickPoint.Web.Models
{
    public class OrderModel
    {
        public int Id { get; set; }
        public int Status { get; set; }
        [Range(0, double.MaxValue, ErrorMessage = WebConsts.QueryError)]
        public decimal TotalCost { get; set; }
        [Required]
        [RegularExpression(WebConsts.PostamatNumberFormat, ErrorMessage = WebConsts.QueryError)]
        public string Postamat { get; set; }
        [Required]
        [MaxLength(64, ErrorMessage = WebConsts.QueryError)]
        [RegularExpression(WebConsts.PhoneNumberFormat, ErrorMessage = WebConsts.QueryError)]
        public string RecipientPhoneNumber { get; set; }
        [Required]
        [MaxLength(255, ErrorMessage = WebConsts.QueryError)]
        public string RecipientName { get; set; }
        [MaxLength(WebConsts.MaxOrderDetailCount, ErrorMessage = WebConsts.QueryError)]
        public string[] Products { get; set; }
    }
}
