﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using PickPoint.Domain.Entities;
using PickPoint.Domain.Repositories;
using PickPoint.Utility;
using AutoMapper;
using PickPoint.Web.Models;
using PickPoint.Utility.Factories;

namespace PickPoint.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository orderRepository;
        private readonly IPostamatRepository postamatRepository;
        private readonly IMapper mapper;

        public OrderController(IOrderRepository orderRepository, IPostamatRepository postamatRepository, IMapper mapper)
        {
            this.orderRepository = orderRepository;
            this.postamatRepository = postamatRepository;
            this.mapper = mapper;
        }

        // GET: api/Order
        [HttpGet]
        public IEnumerable<OrderModel> GetOrders()
        {
            var orders = orderRepository
                .GetAll(OrderSpecificationFactory.GetByStatus(Domain.Enums.OrderStatus.Canceled, true), new string[] { nameof(Order.Postamat), nameof(Order.OrderDetails)} );

            return orders
                .Select(e => mapper.Map<OrderModel>(e))
                .ToList();
        }

        // GET: api/Order/5
        [HttpGet("{id}")]
        public OrderModel GetOrder(int id)
        {
            var order = orderRepository
                .FirstOrDefault(OrderSpecificationFactory.GetById(id), new string[] { nameof(Order.Postamat), nameof(Order.OrderDetails) });
            return mapper.Map<OrderModel>(order);
        }

        // PUT: api/Order/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public string PutOrder(int id, OrderModel model)
        {
            if (!ModelState.IsValid)
            {
                return WebConsts.QueryError;
            }

            if (id != model.Id)
            {
                return WebConsts.QueryError;
            }

            var order = mapper.Map<Order>(model);
            var postamat = postamatRepository.FirstOrDefault(PostamatSpecificationFactory.GetByNumber(model.Postamat));
            if (postamat == null)
            {
                return WebConsts.QueryError;
            }
            order.PostamatId = postamat.Id;
            var result = CheckEnteredOrder(order);
            if (result != null)
            {
                return result;
            }

            UpdateOrderInDb(order);

            return null;
        }

        // POST: api/Order
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public string PostOrder(OrderModel model)
        {
            if (!ModelState.IsValid)
            {
                return WebConsts.QueryError;
            }

            var order = mapper.Map<Order>(model);
            var postamat = postamatRepository.FirstOrDefault(PostamatSpecificationFactory.GetByNumber(model.Postamat));
            if (postamat == null)
            {
                return WebConsts.QueryError;
            }
            order.PostamatId = postamat.Id;
            var result = CheckEnteredOrder(order);
            if (result != null)
            {
                return result;
            }

            AddOrderToDb(order);

            return null;
        }

        // DELETE: api/Order/5
        [HttpDelete("{id}")]
        public string DeleteOrder(int id)
        {
            if (!ModelState.IsValid)
            {
                return WebConsts.QueryError;
            }

            var order = orderRepository.Get(id);
            if (order == null)
            {
                return WebConsts.OrderNotFound;
            }
            if (order.Status == Domain.Enums.OrderStatus.Canceled)
            {
                return WebConsts.OrderAlreadyCancelled;
            }

            RemoveOrderFromDb(order);

            return null;
        }

        private string CheckEnteredOrder(Order order)
        {
            if (order.OrderDetails.Count > WebConsts.MaxOrderDetailCount)
            {
                return WebConsts.QueryError;
            }

            var postamat = postamatRepository.Get(order.PostamatId);
            if (postamat == null)
            {
                return WebConsts.PostamatNotFound;
            }
            if (!postamat.Status)
            {
                return WebConsts.Restricted;
            }

            order.Postamat = postamat;

            return null;
        }

        private void AddOrderToDb(Order order)
        {
            var dbOrder = new Order
            {
                Postamat = order.Postamat,
                Status = Domain.Enums.OrderStatus.Registered,
                RecipientName = order.RecipientName,
                RecipientPhoneNumber = order.RecipientPhoneNumber,
                TotalCost = order.TotalCost
            };

            dbOrder.OrderDetails = order.OrderDetails.Select(e => new OrderDetail
            {
                OrderHeader = dbOrder,
                ProductName = e.ProductName
            }).ToList();

            orderRepository.Add(order);
            orderRepository.Save();
        }

        private void UpdateOrderInDb(Order order)
        {
            var dbOrderHeader = orderRepository
                .FirstOrDefault(OrderSpecificationFactory.GetById(order.Id), new string[] { nameof(Order.OrderDetails) });

            dbOrderHeader.Postamat = order.Postamat;
            dbOrderHeader.RecipientName = order.RecipientName;
            dbOrderHeader.RecipientPhoneNumber = order.RecipientPhoneNumber;
            dbOrderHeader.TotalCost = order.TotalCost;
            dbOrderHeader.OrderDetails.Clear();
            foreach (var detail in order.OrderDetails)
            {
                dbOrderHeader.OrderDetails.Add(new OrderDetail { OrderHeader = dbOrderHeader, ProductName = detail.ProductName });
            }
            orderRepository.Save();
        }

        private void RemoveOrderFromDb(Order order)
        {
            order.Status = Domain.Enums.OrderStatus.Canceled;
            orderRepository.Save();
        }
    }
}
