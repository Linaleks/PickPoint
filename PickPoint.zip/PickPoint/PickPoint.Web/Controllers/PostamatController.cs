﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using PickPoint.Domain.Entities;
using PickPoint.Domain.Repositories;
using PickPoint.Web.Models;
using PickPoint.Utility;
using PickPoint.Utility.Factories;

namespace PickPoint.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostamatController : ControllerBase
    {
        private readonly IPostamatRepository postamatRepository;
        private readonly IMapper mapper;

        public PostamatController(IPostamatRepository postamatRepository, IMapper mapper)
        {
            this.postamatRepository = postamatRepository;
            this.mapper = mapper;
        }

        [HttpGet]
        public IEnumerable<PostamatModel> GetWorkedPostamats()
        {
            return postamatRepository
                .GetAll(PostamatSpecificationFactory.GetByStatus(true), e => e.Number)
                .Select(e => mapper.Map<PostamatModel>(e))
                .ToList();
        }

        [HttpGet("{number}")]
        public PostamatModel GetPostamat(string number)
        {
            return mapper.Map<PostamatModel>(postamatRepository.FirstOrDefault(PostamatSpecificationFactory.GetByNumber(number)));
        }

        [HttpPut("{number}")]
        public string PutPostamat(string number, PostamatModel model)
        {
            if (!ModelState.IsValid)
            {
                return WebConsts.QueryError;
            }

            if (number != model.Number)
            {
                return WebConsts.QueryError;
            }

            var postamat = mapper.Map<Postamat>(model);

            var dbPostamat = postamatRepository.FirstOrDefault(PostamatSpecificationFactory.GetByNumber(number));
            if (dbPostamat == null)
            {
                return WebConsts.QueryError;
            }

            UpdatePostamatInDb(postamat, dbPostamat);

            return null;
        }

        [HttpPost]
        public PostamatModel PostPostamat(PostamatModel model)
        {
            if (!ModelState.IsValid)
            {
                return null;
            }
            else if (postamatRepository.FirstOrDefault(PostamatSpecificationFactory.GetByNumber(model.Number)) != null)
            {
                return null;
            }

            var postamat = mapper.Map<Postamat>(model);
            if (postamat == null)
            {
                return null;
            }

            AddPostamatToDb(postamat);

            return GetPostamat(postamat.Number);
        }

        // DELETE: api/Postamats/5
        [HttpDelete("{number}")]
        public void DeletePostamat(string number)
        {
            if (!ModelState.IsValid)
            {
                return;
            }

            var postamat = postamatRepository.FirstOrDefault(PostamatSpecificationFactory.GetByNumber(number));
            if (postamat == null)
            {
                return;
            }

            RemovePostamatFromDb(postamat);
        }

        private void AddPostamatToDb(Postamat postamat)
        {
            postamatRepository.Add(postamat);
            postamatRepository.Save();
        }

        private void UpdatePostamatInDb(Postamat postamat, Postamat dbPostamat)
        {
            dbPostamat.Address = postamat.Address;
            dbPostamat.Status = postamat.Status;

            postamatRepository.Save();
        }

        private void RemovePostamatFromDb(Postamat postamat)
        {
            postamatRepository.Remove(postamat);
            postamatRepository.Save();
        }
    }
}
